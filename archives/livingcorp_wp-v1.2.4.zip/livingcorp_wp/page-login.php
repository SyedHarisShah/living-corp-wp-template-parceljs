<?php
/*
 * Template Name: Template Login
 */
include('header.php');
?>
<?php
?>
<div id="content" data-template="login"></div>

</body>
  <script sync="" type="module" src="<?php echo get_template_directory_uri(); ?>/index.js?ver=<?= sdv_get_theme_version() ?>"></script>
</html>
